/*
 * adpcm.h
 */
#include "sox.h"

#ifndef SAMPL
#define SAMPL short
#endif

/* default coef sets */
extern const short iCoef[7][2];

/* AdpcmBlockExpandI() outputs interleaved samples into one output buffer */
extern const char *AdpcmBlockExpandI(
	unsigned chans,          /* total channels             */
	int nCoef,
	const short *iCoef,
	const unsigned char *ibuff,/* input buffer[blockAlign]   */
	SAMPL *obuff,       /* output samples, n*chans    */
	int n               /* samples to decode PER channel, REQUIRE n % 8 == 1  */
);

extern void AdpcmBlockMashI(
	unsigned chans,          /* total channels */
	const SAMPL *ip,    /* ip[n*chans] is interleaved input samples */
	int n,              /* samples to encode PER channel, REQUIRE */
	int *st,            /* input/output steps, 16<=st[i] */
	unsigned char *obuff,      /* output buffer[blockAlign] */
	int blockAlign      /* >= 7*chans + n/2          */
);

/* Some helper functions for computing samples/block and blockalign */

/*
 * AdpcmSamplesIn(dataLen, chans, blockAlign, samplesPerBlock)
 *  returns the number of samples/channel which would be
 *  in the dataLen, given the other parameters ...
 *  if input samplesPerBlock is 0, then returns the max
 *  samplesPerBlock which would go into a block of size blockAlign
 *  Yes, it is confusing usage.
 */
extern sox_size_t AdpcmSamplesIn(
	sox_size_t dataLen,
	sox_size_t chans,
	sox_size_t blockAlign,
	sox_size_t samplesPerBlock
);

/*
 * sox_size_t AdpcmBytesPerBlock(chans, samplesPerBlock)
 *   return minimum blocksize which would be required
 *   to encode number of chans with given samplesPerBlock
 */
extern sox_size_t AdpcmBytesPerBlock(
	sox_size_t chans,
	sox_size_t samplesPerBlock
);
